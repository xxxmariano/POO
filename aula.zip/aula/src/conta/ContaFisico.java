
package conta;

import cliente.Fisico;


class ContaFisico extends Conta {
    private Fisico cliente;
   

    public ContaFisico(String NumConta, String NumAgencia, Fisico cliente) {
        super(NumConta, NumAgencia);
        this.cliente=cliente;
    }

    /**
     * @return the cliente
     */
    public Fisico getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Fisico cliente) {
        this.cliente = cliente;
    }
    
}

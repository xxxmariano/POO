
package conta;

import cliente.Juridico;


public class ContaJuridico extends Conta {
    private Juridico cliente;

    public ContaJuridico(String NumConta, String NumAgencia,Juridico cliente) {
        super(NumConta, NumAgencia);
        this.cliente=cliente;
    }

   
    public Juridico getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Juridico cliente) {
        this.cliente = cliente;
    }
    
    
}

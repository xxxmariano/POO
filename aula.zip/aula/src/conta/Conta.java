/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conta;


public class Conta {
    private String NumConta;
    private String NumAgencia;
    
    public Conta( String NumConta,String NumAgencia){
    this.NumConta = NumConta;
    this.NumAgencia = NumAgencia;
    
    }

    /**
     * @return the NumConta
     */
    public String getNumConta() {
        return NumConta;
    }

    /**
     * @param NumConta the NumConta to set
     */
    public void setNumConta(String NumConta) {
        this.NumConta = NumConta;
    }

    /**
     * @return the NumAgencia
     */
    public String getNumAgencia() {
        return NumAgencia;
    }

    /**
     * @param NumAgencia the NumAgencia to set
     */
    public void setNumAgencia(String NumAgencia) {
        this.NumAgencia = NumAgencia;
    }
    
    
    
    
    
    
    
}

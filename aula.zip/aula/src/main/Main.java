
package main;

import cliente.Fisico;
import cliente.Juridico;


public class Main {
    public static void main(String[] args) {
        Fisico cf = new Fisico("Gabriel","8888888");
        Juridico cj = new Juridico("Mariano","1111111111111");
        ContaFisico contf new 
    }
    
}


package construtores;


public class Contador extends Funcionario{
    private int qtdImpostos;
    private String Taxas;

    public Contador(String nome, String cpf, double salario,int qtdImpostos) {
        super(nome, cpf, salario);
        this.qtdImpostos = qtdImpostos;
    }
    

    /**
     * @return the qtdImpostos
     */
    public int getQtdImpostos() {
        return qtdImpostos;
    }

    /**
     * @param qtdImpostos the qtdImpostos to set
     */
    public void setQtdImpostos(int qtdImpostos) {
        this.qtdImpostos = qtdImpostos;
    }

    /**
     * @return the Taxas
     */
    public String getTaxas() {
        return Taxas;
    }

    /**
     * @param Taxas the Taxas to set
     */
    public void setTaxas(String Taxas) {
        this.Taxas = Taxas;
    }
}


package construtores;

public class TecTi extends Funcionario {
    private int QtdLabResponsavel;
    private int numeroPcsConcertados;

    public TecTi(String nome, String cpf, double salario,int QtdLabResponsavel) {
        super(nome, cpf, salario);
        this.QtdLabResponsavel=QtdLabResponsavel;
    }


    /**
     * @return the QtdLabResponsavel
     */
    public int getQtdLabResponsavel() {
        return QtdLabResponsavel;
    }

    /**
     * @param QtdLabResponsavel the QtdLabResponsavel to set
     */
    public void setQtdLabResponsavel(int QtdLabResponsavel) {
        this.QtdLabResponsavel = QtdLabResponsavel;
    }

    /**
     * @return the numeroPcsConcertados
     */
    public int getNumeroPcsConcertados() {
        return numeroPcsConcertados;
    }

    /**
     * @param numeroPcsConcertados the numeroPcsConcertados to set
     */
    public void setNumeroPcsConcertados(int numeroPcsConcertados) {
        this.numeroPcsConcertados = numeroPcsConcertados;
    }
}

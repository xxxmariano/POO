
package construtores;


public class Recepionistas extends Funcionario {
    private int QtdClientesAtendidos;
    private String NomeCliente;

    public Recepionistas(String nome, String cpf, double salario, String NomeCliente) {
        super(nome, cpf, salario);
        this.NomeCliente = NomeCliente;
    }

    /**
     * @return the QtdClientesAtendidos
     */
    public int getQtdClientesAtendidos() {
        return QtdClientesAtendidos;
    }

    /**
     * @param QtdClientesAtendidos the QtdClientesAtendidos to set
     */
    public void setQtdClientesAtendidos(int QtdClientesAtendidos) {
        this.QtdClientesAtendidos = QtdClientesAtendidos;
    }

    /**
     * @return the NomeCliente
     */
    public String getNomeCliente() {
        return NomeCliente;
    }

    /**
     * @param NomeCliente the NomeCliente to set
     */
    public void setNomeCliente(String NomeCliente) {
        this.NomeCliente = NomeCliente;
    }
}

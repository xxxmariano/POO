
package construtores;


public class Funcionario extends Pessoa {
    private String horarioEnt;
     private String horarioSaida;
     private double salario;

    public Funcionario(String nome, String cpf, double salario) {
        super(nome, cpf);
        this.salario = salario;
    }

    /**
     * @return the horarioEnt
     */
    public String getHorarioEnt() {
        return horarioEnt;
    }

    /**
     * @param horarioEnt the horarioEnt to set
     */
    public void setHorarioEnt(String horarioEnt) {
        this.horarioEnt = horarioEnt;
    }

    /**
     * @return the horarioSaida
     */
    public String getHorarioSaida() {
        return horarioSaida;
    }

    /**
     * @param horarioSaida the horarioSaida to set
     */
    public void setHorarioSaida(String horarioSaida) {
        this.horarioSaida = horarioSaida;
    }

    /**
     * @return the salario
     */
    public double getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }

    
}
   

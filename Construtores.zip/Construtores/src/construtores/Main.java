
package construtores;

public class Main {
    public static void main(String[] args){
        Pessoa p1 = new Pessoa("Fabricio","000.000.000-00");
        Funcionario f1 = new Funcionario();
    }
}

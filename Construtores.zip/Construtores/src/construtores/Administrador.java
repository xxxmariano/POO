
package construtores;


public class Administrador extends Funcionario {
    private int QtdOrçamento;
    private String Qtdsetores;

    public Administrador(String nome, String cpf, double salario, int QtdOrçamentos) {
        super(nome, cpf, salario);
        this.QtdOrçamento=QtdOrçamento;
    }

   

    /**
     * @return the QtdOrçamento
     */
    public int getQtdOrçamento() {
        return QtdOrçamento;
    }

    /**
     * @param QtdOrçamento the QtdOrçamento to set
     */
    public void setQtdOrçamento(int QtdOrçamento) {
        this.QtdOrçamento = QtdOrçamento;
    }

    /**
     * @return the Qtdsetores
     */
    public String getQtdsetores() {
        return Qtdsetores;
    }

    /**
     * @param Qtdsetores the Qtdsetores to set
     */
    public void setQtdsetores(String Qtdsetores) {
        this.Qtdsetores = Qtdsetores;
    }
}

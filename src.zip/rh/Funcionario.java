
package rh;


public class Funcionario {
    public double salario;
    public  String nome;
    public  String dataContratação;
    
    public void inss(){ }
    
}

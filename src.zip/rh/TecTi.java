
package rh;


public class TecTi extends Funcionario {
    
     @Override
     public void inss( ){ System.out.println(salario/100*9 + " seu inss é " );
     
     }
     
}

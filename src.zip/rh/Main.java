/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rh;

public class Main {
    public static void main(String[] args) {
    TecTi tec1 = new  TecTi();
    Administrador adm = new Administrador();
    Contador cont = new Contador();
    
    tec1.nome="gabriel";
    tec1.dataContratação="04/12/2010";
    tec1.salario=1000;
    tec1.inss();
    
    adm.nome="gabriel";
    adm.dataContratação="04/12/2010";
    adm.salario=1100;
    adm.inss();
    
    
    cont.nome="gabriel";
    cont.dataContratação="04/12/2010";
    cont.salario=1100;
    cont.inss();
    }
  

}

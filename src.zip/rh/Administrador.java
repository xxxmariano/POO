
package rh;


public class Administrador extends Funcionario{
        public void inss( ){ System.out.println(salario/100*10 + " seu inss é " );
     
     } 
}


package concessionariaipva;


public class Main {
    public static void main(String[] args) {
        Carro carro = new Carro("1111-1111");
        carro.Cor="vermelho";
        carro.PrecoDeVenda=1000;
        carro.ipve();;
    }
}

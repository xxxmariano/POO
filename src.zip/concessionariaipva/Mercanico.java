
package concessionariaipva;




public class Mercanico extends Carro {
   public double PrecoParaConceta;

    public Mercanico(String placar,double precoParaConceta) {
        super(placar);
        this.PrecoParaConceta=precoParaConceta;
    }
    
}


package concessionariaipva;


public class Vendedor extends Carro{
public double PrecoDeVenda;
    public Vendedor(String placar,double precoDeVenda) {
        super(placar);
        this.PrecoDeVenda=precoDeVenda;
    }
    
}

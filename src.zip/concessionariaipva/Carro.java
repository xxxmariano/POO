
package concessionariaipva;


public class Carro {
    public String Placar;
    public String Cor;
    public double PrecoDeVenda;
   
    public void ipve( ){ System.out.println(" seu ipve é"+PrecoDeVenda/100*2  );}
     
    public  Carro(String placar){
    this.Placar=placar;
    }

    
    
}

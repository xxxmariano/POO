/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petshop;

/**
 *
 * @author Particular
 */
public class Lobo extends Animais{
    public String corDoPelo;
    public void emetirSom(){System.out.println("auuuuuuuuuuuu auuuuuuuuuu ");};
    
}

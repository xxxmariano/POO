
package petshop;



public class Animais {
    public double peso;
    public String membros;
    public int idade;
    public void emetirSom(){};
}

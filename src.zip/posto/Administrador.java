
package posto;




public class Administrador extends Funcionario{
        @Override
     public void inss( ){ System.out.println(" seu inss é "+salario/100*11  );
     
     }
}

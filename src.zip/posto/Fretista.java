
package posto;




public class Fretista extends Funcionario {
    
     @Override
     public void inss( ){ System.out.println(" seu inss é "+salario/100*10  );
     
     }
     
}


package posto;




public class Contador extends Funcionario{
    @Override
     public void inss( ){ System.out.println(" seu inss é "+salario/100*9   );
     
     }
}

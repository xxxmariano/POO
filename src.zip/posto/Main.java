
package posto;



public class Main {
    public static void main(String[] args) {
    Fretista fre = new Fretista();
    
    Administrador adm = new Administrador();
    Contador cont = new Contador();
    
    fre.nome="gabriel";
    fre.dataContratação="04/12/2010";
    fre.salario=1000;
    fre.inss();
    
    adm.nome="gabriel";
    adm.dataContratação="04/12/2010";
    adm.salario=1100;
    adm.inss();
    
    
    cont.nome="gabriel";
    cont.dataContratação="04/12/2010";
    cont.salario=1100;
    cont.inss();
    }
  

}


package concessionaria;

public class Carro {
    public String Placar;
    public String Cor;
    
    
    
    
    public  Carro(String placar){
    this.Placar=placar;
    }

    
    
}


package petshop2;


public class Gato extends Animais{
     public String corDoPelo;
    @Override
     public void emetirSom(){System.out.println("miau miauu ");};
}

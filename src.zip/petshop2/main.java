
package petshop2;


public class main {
    public static void main(String[] args) {
          Cachorro ca = new Cachorro();
          Gato ga = new Gato();
          Lobo lo = new Lobo();
          
          ca.emetirSom();
          ga.emetirSom();
          lo.emetirSom();
    }
}

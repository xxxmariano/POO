
package petshop2;

public class Cachorro extends Animais{
    public String corDoPelo;
    @Override
     public void emetirSom(){System.out.println("au au au au ");};
}

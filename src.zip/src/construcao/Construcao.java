
package construcao;


public abstract class Construcao {
    
}

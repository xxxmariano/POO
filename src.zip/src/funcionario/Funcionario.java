
package funcionario;


public abstract class Funcionario {
    private String HorarioDeEntrada;
    private String HorarioDeSaida;
   public abstract void RegistrarCheganda(String HorarioDeEntrada);
   public abstract void RegistrarSaida(String HorarioDeSaida);

    /**
     * @return the HorarioDeEntrada
     */
    public String getHorarioDeEntrada() {
        return HorarioDeEntrada;
    }

    /**
     * @param HorarioDeEntrada the HorarioDeEntrada to set
     */
    public void setHorarioDeEntrada(String HorarioDeEntrada) {
        this.HorarioDeEntrada = HorarioDeEntrada;
    }

    /**
     * @return the HorarioDeSaida
     */
    public String getHorarioDeSaida() {
        return HorarioDeSaida;
    }

    /**
     * @param HorarioDeSaida the HorarioDeSaida to set
     */
    public void setHorarioDeSaida(String HorarioDeSaida) {
        this.HorarioDeSaida = HorarioDeSaida;
    }
    
    
}

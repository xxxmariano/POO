/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funcionario;


public class TecTi extends Funcionario {
     @Override
    public void RegistrarCheganda(String HorarioDeEntrada) {
        System.out.println("Você Chegou as"+HorarioDeEntrada );
    }
    @Override
    public void RegistrarSaida(String HorarioDeSaida) {
       System.out.println("Você Chegou as"+HorarioDeSaida );
    }
}

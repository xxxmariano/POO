
package funcionario;


public class Recepcionista extends Funcionario {

    @Override
    public void RegistrarCheganda(String HorarioDeEntrada) {
        System.out.println("Você Chegou as"+HorarioDeEntrada );
    }
    @Override
    public void RegistrarSaida(String HorarioDeSaida) {
       System.out.println("Você Chegou as"+HorarioDeSaida );
    }
    
}
